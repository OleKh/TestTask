<?php
class Model extends Db {

    public function __construct(){
        parent::__construct();
    }

}